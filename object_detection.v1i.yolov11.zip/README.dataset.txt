# object detection > 2025-08-10 4:37pm
https://universe.roboflow.com/hwy10/object-detection-oygmp

Provided by a Roboflow user
License: CC BY 4.0

